<?php

if(!function_exists('qode_advanced_pricing_list_map')) {
    function qode_advanced_pricing_list_map() {



	}

    add_action('qode_options_elements_page_map', 'qode_advanced_pricing_list_map');
}