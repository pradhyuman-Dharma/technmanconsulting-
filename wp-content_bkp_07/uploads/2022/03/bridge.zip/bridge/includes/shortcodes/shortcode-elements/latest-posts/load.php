<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/latest-posts/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/latest-posts/latest-posts.php';