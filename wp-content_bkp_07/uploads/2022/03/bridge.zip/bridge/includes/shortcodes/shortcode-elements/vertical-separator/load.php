<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/vertical-separator/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/vertical-separator/vertical-separator.php';