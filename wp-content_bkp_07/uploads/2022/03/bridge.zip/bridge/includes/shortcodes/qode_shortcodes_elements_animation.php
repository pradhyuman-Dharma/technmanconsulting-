<div id="qode_shortcode_form_wrapper">
<form id="qode_shortcode_form" name="qode_shortcode_form" method="post" action="">
  <div class="input">
		<label>Animation Type</label>
      <select name="animation_type" id="animation_type">
          <option value="element_from_left">Elements Shows From Left Side</option>
          <option value="element_from_right">Elements Shows From Right Side</option>
          <option value="element_from_top">Elements Shows From Top Side</option>
          <option value="element_from_bottom">Elements Shows From Bottom Side</option>
          <option value="element_from_fade">Elements Shows From Fade</option>
      </select>
  </div>
  <div class="input">
      <input type="submit" name="Insert" id="qode_insert_shortcode_button" value="Submit" />
  </div>
</form>
</div>