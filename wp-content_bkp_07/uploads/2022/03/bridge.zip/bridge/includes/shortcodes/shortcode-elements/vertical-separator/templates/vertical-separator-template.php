<div class="qode_vertical_separator" <?php qode_inline_style($holder_style); ?>>
</div>