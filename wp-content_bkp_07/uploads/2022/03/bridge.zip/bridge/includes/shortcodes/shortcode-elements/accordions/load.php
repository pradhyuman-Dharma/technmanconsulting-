<?php
require_once QODE_SHORTCODES_ROOT_DIR.'/accordions/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/accordions/accordion.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/accordions/accordion-tab.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/accordions/custom-styles/custom-styles.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/accordions/options-map/map.php';
