<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/simple-quote/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/simple-quote/simple-quote.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/simple-quote/custom-styles/custom-styles.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/simple-quote/options-map/map.php';