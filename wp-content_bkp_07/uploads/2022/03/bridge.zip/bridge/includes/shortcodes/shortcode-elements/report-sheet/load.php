<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/report-sheet/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/report-sheet/report-sheet.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/report-sheet/options-map/map.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/report-sheet/custom-styles/custom-styles.php';