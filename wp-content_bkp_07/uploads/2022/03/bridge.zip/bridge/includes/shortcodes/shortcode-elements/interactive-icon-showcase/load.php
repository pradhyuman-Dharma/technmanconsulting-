<?php
require_once QODE_SHORTCODES_ROOT_DIR.'/interactive-icon-showcase/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/interactive-icon-showcase/interactive-icon-showcase.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/interactive-icon-showcase/interactive-icon-showcase-item.php';
