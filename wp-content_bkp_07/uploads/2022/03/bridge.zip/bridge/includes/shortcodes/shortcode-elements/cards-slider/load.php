<?php
include_once QODE_SHORTCODES_ROOT_DIR.'/cards-slider/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/cards-slider/cards-slider.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/cards-slider/cards-slider-item.php';