<?php
include_once QODE_SHORTCODES_ROOT_DIR.'/sliding-image-holder/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/sliding-image-holder/sliding-image-holder.php';